import { Component, OnInit } from '@angular/core';
import {BooklistService} from './../booklist.service';
@Component({
  selector: 'app-book2',
  templateUrl: './book2.component.html',
  styleUrls: ['./book2.component.css']
})
export class Book2Component implements OnInit {

  books:Book[];

  constructor(private booklistservice: BooklistService) { }

  ngOnInit() {
   this.booklistservice.getJSON().subscribe((booksData)=>this.books=booksData);
  }

}
export interface Book
{
	id : number;
	title : string;
	year : number;
	author : string;
}
