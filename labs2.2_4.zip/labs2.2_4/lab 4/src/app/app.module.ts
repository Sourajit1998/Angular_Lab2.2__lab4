import { HttpClientModule } from '@angular/common/http';
import { BooklistService } from './booklist.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchPipe } from './filterBookData';
import { SearchAuthorPipe } from './filterBookAuthor';

@NgModule({
  declarations: [
    AppComponent,
    SearchPipe,
    SearchAuthorPipe,
    routingComponents,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [BooklistService],
  bootstrap: [AppComponent]
})
export class AppModule { }
