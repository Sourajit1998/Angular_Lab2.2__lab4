import { Component, OnInit } from '@angular/core';
import {BooklistService} from './../booklist.service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  books:Book[];

  constructor(private booklistservice: BooklistService) { }

  ngOnInit() {
   this.booklistservice.getJSON().subscribe((booksData)=>this.books=booksData);
  }

  deleteOnClick(event)
  {
      var del_loc_value=event.target.parentNode.parentNode.children[0].textContent;
      for(var i=0;i<this.books.length;i++)
      {
        if(del_loc_value==this.books[i].id)
        {
              this.books.splice(i,1);
        }
      }
  }
}
export interface Book
{
	id : number;
	title : string;
	year : number;
	author : string;
}

