import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BookComponent} from './book/book.component';
import {Book2Component} from './book2/book2.component';
import { ProductsComponent } from './products/products.component';

const routes: Routes = [
  {path:'book1',component:BookComponent},
  {path:'book2',component:Book2Component},
  {path:'products',component:ProductsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[BookComponent,Book2Component,ProductsComponent];
