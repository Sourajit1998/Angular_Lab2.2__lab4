import { Component, OnInit } from '@angular/core';
import {EmployeeDetailsService} from './../employee-details.service';
@Component({
  selector: 'app-employee-component',
  templateUrl: './employee-component.component.html',
  styleUrls: ['./employee-component.component.css']
})
export class EmployeeComponentComponent implements OnInit {

  employees:Employee[];

  constructor(private EmployeeDetails: EmployeeDetailsService) { }

  ngOnInit() {
   this.EmployeeDetails.getJSON().subscribe((employeesdata)=>this.employees=employeesdata);
  }

  sortByID()
  {
    for(var i=0;i<this.employees.length-1;i++)
    {
      for(var j=i+1;j<this.employees.length;j++)
      {
        if(this.employees[i].empId > this.employees[j].empId)
        {
          var temp;
          temp=this.employees[i];
          this.employees[i]=this.employees[j];
          this.employees[j]=temp;
        }
      }
    }
  }
  
  sortByName()
  {
    for(var i=0;i<this.employees.length-1;i++)
    {
      for(var j=i+1;j<this.employees.length;j++)
      {
        if(this.employees[i].empName > this.employees[j].empName)
        {
          var temp;
          temp=this.employees[i];
          this.employees[i]=this.employees[j];
          this.employees[j]=temp;
        }
      }
    }
  }

  sortBySal()
  {
    for(var i=0;i<this.employees.length-1;i++)
    {
      for(var j=i+1;j<this.employees.length;j++)
      {
        if(this.employees[i].empSal > this.employees[j].empSal)
        {
          var temp;
          temp=this.employees[i];
          this.employees[i]=this.employees[j];
          this.employees[j]=temp;
        }
      }
    }
  }

  sortByDep()
  {
    for(var i=0;i<this.employees.length-1;i++)
    {
      for(var j=i+1;j<this.employees.length;j++)
      {
        if(this.employees[i].empDep > this.employees[j].empDep)
        {
          var temp;
          temp=this.employees[i];
          this.employees[i]=this.employees[j];
          this.employees[j]=temp;
        }
      }
    }
  }

  deleteOnClick(event)
  {
       var delete_loc_value=event.target.parentNode.parentNode.children[0].textContent;
       for(var i=0;i<this.employees.length;i++)
       {
          if(delete_loc_value==this.employees[i].empId)
          {
                this.employees.splice(i,1);
          }
        }
  }
}

export interface Employee
{
	empId : number;
	empName : string;
	empSal : number;
  empDep : string;
  empjoiningdate:string;
}
