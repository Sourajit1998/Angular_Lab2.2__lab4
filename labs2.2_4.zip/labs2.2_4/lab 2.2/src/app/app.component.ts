import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-employee-component></app-employee-component>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
