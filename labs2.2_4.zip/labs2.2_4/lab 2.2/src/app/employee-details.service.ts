import { Injectable } from '@angular/core';
import { EmployeeComponentComponent } from './employee-component/employee-component.component';
import { Observable } from 'rxjs/internal/Observable';
import {  HttpClient } from '@angular/common/http';
import { Employee } from './employee-component/employee-component.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  constructor(private http:HttpClient) {}
	public getJSON():Observable<Employee[]>{
			return this.http.get<Employee[]>('assets/employees.json');
    }
}
